import torch
from torch import nn
class FashionMNISTModelV2(nn.Module):
    def __init__(self, input_shape: int, hidden_units: int, output_shape: int):
        """
        Start Coding Here
        """
    
    def forward(self, x: torch.Tensor):
        """
        Start Coding Here
        """
        return None #<------------ Replace None with the output of the model